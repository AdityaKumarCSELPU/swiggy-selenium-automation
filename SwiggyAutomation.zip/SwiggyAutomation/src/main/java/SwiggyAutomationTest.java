import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.OutputType;

import io.github.bonigarcia.wdm.WebDriverManager;

import java.io.File;
import java.io.IOException;
import java.time.Duration;

import org.apache.commons.io.FileUtils;

public class SwiggyAutomationTest {

    public static void main(String[] args) throws InterruptedException, IOException {

        // Setup driver
        WebDriverManager.chromedriver().setup();

        ChromeOptions options = new ChromeOptions();

        // Fix Swiggy 403 block
        options.addArguments("--disable-blink-features=AutomationControlled");
        options.addArguments("--start-maximized");
        options.addArguments("--disable-notifications");

        WebDriver driver = new ChromeDriver(options);

        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

        // Open Google first to avoid bot detection
        driver.get("https://www.google.com");
        driver.get("https://www.swiggy.com");

        // Validate Title & URL
        System.out.println("Page Title: " + driver.getTitle());
        System.out.println("Current URL: " + driver.getCurrentUrl());

        // Click Login
        driver.findElement(By.linkText("Login")).click();

        Thread.sleep(2000);

        // Enter phone number
        driver.findElement(By.id("mobile")).sendKeys("9470614425");

        System.out.println("Please enter OTP manually...");

        // Wait for OTP
        Thread.sleep(20000);

        // Enter delivery location
        WebElement location = driver.findElement(By.id("location"));
        location.sendKeys("Bengaluru");

        Thread.sleep(3000);

        // Select first suggestion
        driver.findElement(By.xpath("(//span[contains(@class,'_2WO6n')])[1]")).click();

        Thread.sleep(4000);

        // Click search
        driver.findElement(By.xpath("//span[text()='Search']")).click();

        Thread.sleep(2000);

        // Search restaurant
        driver.findElement(By.xpath("//input[@placeholder='Search for restaurants and food']"))
                .sendKeys("Dominos Pizza");

        Thread.sleep(4000);

        // Select first restaurant
        WebElement restaurant = driver.findElement(By.xpath("(//div[contains(@class,'_1HEuF')])[1]"));

        System.out.println("Selected Restaurant: " + restaurant.getText());

        restaurant.click();

        Thread.sleep(5000);

        // Select second food item
        WebElement foodItem = driver.findElement(By.xpath("(//div[contains(@class,'_1RPOp')])[2]"));

        System.out.println("Selected Food Item: " + foodItem.getText());

        // Add item
        driver.findElement(By.xpath("(//button[text()='ADD'])[2]")).click();

        Thread.sleep(3000);

        takeScreenshot(driver, "ItemAdded");

        // View cart
        driver.findElement(By.xpath("//span[text()='View Cart']")).click();

        Thread.sleep(3000);

        // Increase quantity
        driver.findElement(By.xpath("//div[@class='_1ds9T']")).click();

        Thread.sleep(2000);

        takeScreenshot(driver, "QuantityIncreased");

        // Add new address
        driver.findElement(By.xpath("//span[text()='Add New']")).click();

        Thread.sleep(2000);

        driver.findElement(By.name("address")).sendKeys("Flat 101");

        driver.findElement(By.name("landmark")).sendKeys("Near Park");

        driver.findElement(By.xpath("//span[text()='Home']")).click();

        driver.findElement(By.xpath("//button[contains(text(),'Save Address')]")).click();

        Thread.sleep(3000);

        takeScreenshot(driver, "AddressAdded");

        // Proceed to payment page
        driver.findElement(By.xpath("//button[contains(text(),'Proceed to Pay')]")).click();

        Thread.sleep(3000);

        takeScreenshot(driver, "PaymentPage");

        System.out.println("Reached Payment Page Successfully");

        Thread.sleep(5000);

        driver.quit();
    }

    // Screenshot method
    public static void takeScreenshot(WebDriver driver, String fileName) throws IOException {

        File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

        File dest = new File("screenshots/" + fileName + ".png");

        FileUtils.copyFile(src, dest);
    }
}